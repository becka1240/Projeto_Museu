const express = require('express');
const app = express();
const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://RBK:230507la230507la@cluster0.tekwmco.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");
const Obra = require ("./models/Obra");
const Funcionario = require ("./models/Funcionario");
app.set('view engine','ejs');
app.use(express.urlencoded({extended:true}));
app.use(express.static('public'));

app.post("/obras", async function(req, res){
    const obra = req.body

    const novaObra = new Obra ({
        autor: obra.autor,
        nome: obra.nome,
        identificacao: obra.identificacao
    });

    await novaObra.save();

    res.redirect("/obras?s=1");
});

app.post("/funcionarios", async function(req, res){
    const funcionario = req.body

    const novaFuncionario = new Funcionario ({
        verificacao: funcionario.verificacao,
        nome: funcionario.nome,
        funcao: funcionario.funcao
    });

    await novaFuncionario.save();

    res.redirect("/funcionarios?s=1");
});

app.get("/obras", async function(req, res){
    const status = req.query.s;
    const obras = await Obra.find();
    res.render("obra/relatorioObra",{obras,status});
});

app.get("/funcionarios", async function(req, res){
    const status = req.query.s;
    const funcionarios = await Funcionario.find();
    res.render("funcionario/relatorioFuncionario",{funcionarios,status});
});

app.get("/obras/cadastrarObra", function(req, res){
    res.render("obra/cadastrarObra");
});

app.get("/funcionarios/cadastrarFuncionario", function(req, res){
    res.render("funcionario/cadastrarFuncionario");
});

app.get("/funcionarios/:verificacao", async function(req, res){
    const funcionario = await Funcionario.findOne({verificacao:req.params.verificacao})
    res.render("funcionario/detalharFuncionario",{funcionario});
});

app.get("/obras/:identificacao", async function(req, res){
    const obra = await Obra.findOne({identificacao:req.params.identificacao})
    res.render("obra/detalharObra",{obra});
});

app.get("/", function (req,res){
    const arte ={
        nome: "Noite Estrelada",
        autor: "Van Gogh"
    };

    const pessoa ={
        nome: "Rebecka",
        funcao: "Atendente"
    };
    res.render("index",{arte,pessoa});
});

app.use(function(req, res) {
    res.status(404).render("404");
});

app.listen("999", function(){
    console.log("Rodando");
});




